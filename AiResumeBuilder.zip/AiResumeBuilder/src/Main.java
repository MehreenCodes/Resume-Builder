import javax.swing.*;  //this is for the GUI of the AI resume builder
import java.awt.*;     //this is for the layout of AI resume builder
import java.awt.event.ActionEvent; //this is used to handle events like when buttons are clicked
import java.awt.event.ActionListener; //this is used to write code that runs when buttons are clicked
import java.io.BufferedWriter; //this writes the text data into file format
import java.io.FileWriter; //this helps create and open files to write and make changes
import java.io.IOException; //this handles errors during file writing

public class Main { //this is the main java class called "Main"
    public static void main(String[] args) { //this is the start of the main method of the java application Ai Resume Builder
        SwingUtilities.invokeLater(() -> { //This makes sure that the GUI of the Ai resume builder application happens on the EDT (Event Dispatch Thread)
            JFrame AiResumeBuilderFrame = new JFrame("AI Resume Builder");// this creates and names the frame as "AI Resume Builder"
            AiResumeBuilderFrame.setSize(5000, 1000); // this sets the size of the frame/window screen for the project
            JLabel AiResumeBuilderTitleLabel = new JLabel("Welcome to the AI Resume Builder!", SwingConstants.CENTER); // this is the title label that welcomes user to the Ai resume builder, placed right in the center
            AiResumeBuilderTitleLabel.setFont(new Font("Arial", Font.BOLD, 42)); // this sets the font name,font type and size label for the title label
            AiResumeBuilderFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // this closes the Ai resume Builder application when window is closed

            // starting home page panel
            JPanel AiResumeBuilderHomePagePanel = new JPanel(new GridBagLayout()); //this creates a JPanel, which is a container panel that contains the GUI components for the Ai Resume Builder application like buttons, labels, text fields, etc.
            AiResumeBuilderHomePagePanel.setBackground(new Color(255, 255, 204));  // this sets the background for the home page to a specific light yellow
            GridBagConstraints gbc = new GridBagConstraints(); //this creates a constraint object that defines the position, size, spacing, of components inside the GridBagLayout.
            gbc.insets = new Insets(12, 12, 12, 12); // this adds space around the button components, ensuring they are placed at the center of the screen
            gbc.gridx = 0;  // this places the title label in the first column, column index 0
            gbc.gridy = 0;  // this places the title label in the first row, row index 0
            gbc.gridwidth = 1; // This means the label will span only 1 column, which means that the title label stays inside one column
            gbc.weighty = 0.2; // This gives more vertical weight to the label, which means that Label can have some extra space above and below to avoid looking cramped and messy
            gbc.anchor = GridBagConstraints.CENTER;  // this makes sure that the title label is placed at the center both horizontally and vertically
            AiResumeBuilderHomePagePanel.add(AiResumeBuilderTitleLabel, gbc); // this adds the title label to the home page panel
            JLabel AiResumeBuilderInstructionLabel = new JLabel("Create an account by signing up or simply log in if you already have an account ", SwingConstants.CENTER); // this is the instruction label, telling users and admin to create or log in to the account, placed right in the center
            AiResumeBuilderInstructionLabel.setFont(new Font("Arial", Font.ITALIC, 25)); // this sets the font name, font style and size for the instruction label
            gbc.gridy = 1; // this place the instruction label right under the welcome label
            gbc.weighty = 0.1; // this makes sure that the instruction label has enough vertical space, which means that the label can have some extra space above and below to avoid looking cramped and messy
            AiResumeBuilderHomePagePanel.add(AiResumeBuilderInstructionLabel, gbc); //this adds the instruction label to the Home Page panel,using the GridBagConstraints (gbc) to control the position and layout of the label

            // Creating a panel for the buttons using the GridBagLayout
            JPanel AiResumeBuilderButtonPanel = new JPanel(); // this creates a JPanel, which is a container panel that contains the GUI components for the Ai Resume Builder application like buttons, labels, text fields, etc.
            AiResumeBuilderButtonPanel.setLayout(new GridBagLayout()); //This sets the layout of the button panel for the Ai resume builder so that gui components are arranged flexibly based on the position and size
            GridBagConstraints AiResumeBuilderButtonGbc = new GridBagConstraints(); //this defines how components are positioned,including size and space
            AiResumeBuilderButtonGbc.gridx = 0; // this places all the buttons in the same column making it look neat and tidy
            AiResumeBuilderButtonGbc.insets = new Insets(10, 10, 10, 10); // This is the amount of space around buttons evenly spread

            //signup button for admins
            JButton AiResumeBuilderAdminSignUpButton = new JButton("Admin Sign up"); //this creates the signup button for admins
            AiResumeBuilderAdminSignUpButton.setPreferredSize(new Dimension(200, 60)); //this sets the preferred size for the admin sign up button
            AiResumeBuilderAdminSignUpButton.addActionListener(e -> AiResumeBuilderOpenAdminSignUpPage()); // Calls method for Admin Sign Up page //this loads the admin sign up page after clicking the admin sign up button
            AiResumeBuilderButtonPanel.add(AiResumeBuilderAdminSignUpButton, AiResumeBuilderButtonGbc); //This adds the admin sign up button to the button panel accordingly based on size, position,ect

            //login button for admins
            JButton AiResumeBuilderAdminLoginButton = new JButton("Admin Log in"); // this creates the login button for admins
            AiResumeBuilderAdminLoginButton.setPreferredSize(new Dimension(200, 60)); //this sets the preferred size for the admin log in button
            AiResumeBuilderAdminLoginButton.addActionListener(e -> AiResumeBuilderOpenAdminLoginPage()); // Calls method for Admin Log In page // this loads the admin log in page after clicking the admin log in button
            AiResumeBuilderButtonPanel.add(AiResumeBuilderAdminLoginButton, AiResumeBuilderButtonGbc); //this adds the admin log in button to the button panel accordingly based on size, position,ect

            //signup button for users
            JButton AiResumeBuilderUserSignUpButton = new JButton("User Sign up"); //this creates the signup button for users
            AiResumeBuilderUserSignUpButton.setPreferredSize(new Dimension(200, 60)); //this sets the preferred size for the user sign up button
            AiResumeBuilderUserSignUpButton.addActionListener(e ->  AiResumeBuilderOpenUserSignUpPage()); //this loads the user sign up page after clicking the user sign up button
            AiResumeBuilderButtonPanel.add(AiResumeBuilderUserSignUpButton, AiResumeBuilderButtonGbc); //this adds the user sign up button to the button panel accordingly based on size, position,ect

            //login button for users
            JButton AiResumeBuilderUserLoginButton = new JButton("User Log in"); //this creates the login button for users
            AiResumeBuilderUserLoginButton.setPreferredSize(new Dimension(200, 60)); //this sets the preferred size for the user log in button
            AiResumeBuilderUserLoginButton.addActionListener(e -> AiResumeBuilderOpenUserLoginPage()); //this loads the user log in page after clicking the user log in button
            AiResumeBuilderButtonPanel.add(AiResumeBuilderUserLoginButton, AiResumeBuilderButtonGbc); //this adds the user log in button to the button panel accordingly based on size, position,ect

            //adding the main panel to the actual window frame
            gbc.gridy = 2; //this places the buttons in row 2 gridy of the panel
            gbc.weighty = 0.6; // this gives more vertical space for the button panel
            AiResumeBuilderHomePagePanel.add(AiResumeBuilderButtonPanel, gbc); // this adds the button panel to the Ai resume builder home page panel, and places is based on the layout defined for the gbc
            AiResumeBuilderFrame.add(AiResumeBuilderHomePagePanel); //this adds the main home page panel to the Ai resume builder frame
            AiResumeBuilderFrame.setVisible(true); // this makes sure that the frame is actually visible
        });
    }
    // Admin Sign Up Page
    private static void AiResumeBuilderOpenAdminSignUpPage() { //this method opens the admin sign up page
        JFrame AiResumeBuilderAdminSignUpFrame = new JFrame("Admin Sign Up"); //this creates and names the frame to "Admin Sign up"
        AiResumeBuilderAdminSignUpFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); //this makes sure that admin sign up frame will be closed but the main application will still be running in the background
        AiResumeBuilderAdminSignUpFrame.setSize(5000, 1000); //this sets the size of the frame/window screen for the admin sign up page
        JPanel AiResumeBuilderAdminSignUpPanel = new JPanel(); //this creates the JPanel for the admin sign up page
        AiResumeBuilderAdminSignUpPanel.setLayout(new GridLayout(20, 10, 10, 10)); //this sets the grid layouts for the admin sign up panel

        AiResumeBuilderAdminSignUpPanel.add(new JLabel("First name",SwingConstants.CENTER)); //this creates the JLabel called "First name", placing it at the center
        JTextField AiResumeBuilderAdminSignUpFirstNameField = new JTextField(10); //this creates the first name text field for the admin sign up
        AiResumeBuilderAdminSignUpPanel.add(AiResumeBuilderAdminSignUpFirstNameField); //this adds the first name textfield to the admin sign up panel

        AiResumeBuilderAdminSignUpPanel.add(new JLabel("Last name",SwingConstants.CENTER)); //this creates the JLabel called "Last name", placing it at the center
        JTextField AiResumeBuilderAdminSignUpLastNameField = new JTextField(10); //this creates the last name text field for the admin sign up
        AiResumeBuilderAdminSignUpPanel.add(AiResumeBuilderAdminSignUpLastNameField); //this adds the last name textfield to the admin signup panel

        AiResumeBuilderAdminSignUpPanel.add(new JLabel("Email Address",SwingConstants.CENTER)); //this creates the JLabel called "Email Address", placing it at the center
        JTextField AiResumeBuilderAdminSignUpEmailAddressField = new JTextField(10); //this creates the email address text field for the admin sign up
        AiResumeBuilderAdminSignUpPanel.add(AiResumeBuilderAdminSignUpEmailAddressField); //this adds the email address textfield to the admin signup panel

        AiResumeBuilderAdminSignUpPanel.add(new JLabel("Phone Number (optional)",SwingConstants.CENTER)); //this creates the JLabel called "Phone Number (optional)", placing it at the center
        JTextField AiResumeBuilderAdminSignUpPhoneNumberField = new JTextField(10); //this creates the phone number text field for the admin sign up
        AiResumeBuilderAdminSignUpPanel.add(AiResumeBuilderAdminSignUpPhoneNumberField); //this adds the phone number textfield to the admin signup panel

        AiResumeBuilderAdminSignUpPanel.add(new JLabel("Username:",SwingConstants.CENTER)); //this creates the JLabel called "username", placing it at the center
        JTextField AiResumeBuilderAdminSignUpUsernameField = new JTextField(10); //this creates the username text field for the admin sign up
        AiResumeBuilderAdminSignUpPanel.add(AiResumeBuilderAdminSignUpUsernameField); //this adds the username textfield to the admin signup panel

        AiResumeBuilderAdminSignUpPanel.add(new JLabel("Password:",SwingConstants.CENTER)); //this creates the JLabel called "Password", placing it at the center
        JPasswordField AiResumeBuilderAdminSignUpPasswordField = new JPasswordField(10); //this creates the password text field for the admin sign up
        AiResumeBuilderAdminSignUpPanel.add(AiResumeBuilderAdminSignUpPasswordField); //this adds the password textfield to the admin signup panel

        AiResumeBuilderAdminSignUpPanel.add(new JLabel("Confirm Password:",SwingConstants.CENTER)); //this creates the JLabel called "Confirm Password", placing it at the center
        JPasswordField AiResumeBuilderAdminSignUpConfirmPasswordField = new JPasswordField(10); //this creates the Confirm password field text field for the admin sign up
        AiResumeBuilderAdminSignUpPanel.add(AiResumeBuilderAdminSignUpConfirmPasswordField); //this adds the Confirm password textfield to the admin signup panel

        AiResumeBuilderAdminSignUpPanel.add(Box.createRigidArea(new Dimension(0, 10))); //this adds space around the admin sign up panel

        JButton AiResumeBuilderAdminSignUpSubmitButton = new JButton("Submit"); //this adds the JButton called submit to the admin sign up page
        AiResumeBuilderAdminSignUpPanel.add(AiResumeBuilderAdminSignUpSubmitButton); //this adds the admin sign up button to the admin signup panel
        AiResumeBuilderAdminSignUpFrame.add(AiResumeBuilderAdminSignUpPanel); //this adds the admin sign up panel to the admin sign up frame
        AiResumeBuilderAdminSignUpFrame.setVisible(true); //this makes sure that the admin sign up frame is actually visible
        AiResumeBuilderAdminSignUpSubmitButton.addActionListener(e -> { //this shows a message after admins click the submit button for signing up
            JOptionPane.showMessageDialog(null, "Account has been successfully created", "welcome to the Ai Resume Builder", JOptionPane.INFORMATION_MESSAGE); //this shows the message dialog
        });
    }
    // Admin Log In Page
    private static void AiResumeBuilderOpenAdminLoginPage() { //this method opens admin login page
        JFrame AiResumeBuilderAdminLoginFrame = new JFrame("Admin Login"); //this creates and names the frame to "Admin Login"
        AiResumeBuilderAdminLoginFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); //this makes sure that the admin login frame will be closed but the main application will still be running in the background
        AiResumeBuilderAdminLoginFrame.setSize(5000, 1000); //this sets the size of the frame/window screen for the admin login page
        JPanel AiResumeBuilderAdminLoginPanel = new JPanel(); //this creates the JPanel for the admin login page
        AiResumeBuilderAdminLoginPanel.setLayout(new GridLayout(20, 10, 10, 10)); //this sets the grid layouts for the admin login panel

        AiResumeBuilderAdminLoginPanel.add(Box.createRigidArea(new Dimension(0, 10))); //this adds space around the admin login panel

        AiResumeBuilderAdminLoginPanel.add(new JLabel("Username:",SwingConstants.CENTER)); //this creates the JLabel called "Username", placing it at the center
        JTextField AiResumeBuilderAdminLoginUsernameField = new JTextField(10); //this creates the Username text field for the admin login
        AiResumeBuilderAdminLoginPanel.add(AiResumeBuilderAdminLoginUsernameField); //this adds the username textfield to the admin login panel

        AiResumeBuilderAdminLoginPanel.add(Box.createRigidArea(new Dimension(0, 10))); //this adds space around the admin login panel

        AiResumeBuilderAdminLoginPanel.add(new JLabel("Password:",SwingConstants.CENTER)); //this creates the JLabel called "Password", placing it at the center
        JPasswordField AiResumeBuilderAdminLoginPasswordField = new JPasswordField(10); //this creates the password text field for the admin login
        AiResumeBuilderAdminLoginPanel.add(AiResumeBuilderAdminLoginPasswordField); //this adds the password textfield to the admin login panel

        AiResumeBuilderAdminLoginPanel.add(Box.createRigidArea(new Dimension(0, 10))); //this adds space around the admin login panel

        JButton AiResumeBuilderAdminLoginSubmitButton = new JButton("Submit"); //this adds the JButton called submit to the admin login page
        AiResumeBuilderAdminLoginPanel.add(AiResumeBuilderAdminLoginSubmitButton); //this adds the admin login button to the admin login panel

        AiResumeBuilderAdminLoginFrame.add(AiResumeBuilderAdminLoginPanel); //this adds the admin login panel to the admin login frame
        AiResumeBuilderAdminLoginFrame.setVisible(true); //this makes sure that the admin login frame is actually visible
        AiResumeBuilderAdminLoginSubmitButton.addActionListener(e -> { //this action listener waits for login submit button to be clicked to open the next window
            AiResumeBuilderAdminLoginFrame.dispose(); // this closes the login frame, keeping the home page running in the background
            AiResumeBuilderOpenAdminResumeModificationPage(); // this opens the admin resume modification page
        });
        AiResumeBuilderAdminLoginPanel.add(AiResumeBuilderAdminLoginSubmitButton); //this adds the login submit button to the admin login panel
        AiResumeBuilderAdminLoginFrame.add(AiResumeBuilderAdminLoginPanel); //this adds the admin login panel to the admin login frame
        AiResumeBuilderAdminLoginFrame.setVisible(true); //this makes the actual admin login frame visible
    }

    private static void AiResumeBuilderOpenAdminResumeModificationPage(){ //this method opens the admin modification page
        JFrame AiResumeBuilderAdminResumeModificationFrame = new JFrame("Admin Resume Modification"); //this creates and names the frame to "Resume Modification"
        AiResumeBuilderAdminResumeModificationFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); //this makes sure that the frame will be closed but the main application will still be running in the background
        AiResumeBuilderAdminResumeModificationFrame.setSize(5000, 1000); //this sets the size of the frame/window screen
        JPanel AiResumeBuilderAdminResumeModificationPanel = new JPanel(); //this creates the JPanel for the admin resume modification
        AiResumeBuilderAdminResumeModificationPanel.setLayout(new BoxLayout(AiResumeBuilderAdminResumeModificationPanel, BoxLayout.Y_AXIS)); // this sets the panel layout to Vertical Y axis BoxLayout
        AiResumeBuilderAdminResumeModificationPanel.add(Box.createRigidArea(new Dimension(0, 30))); //this adds space around the admin resume modification panel

        JLabel AiResumeBuilderAdminModificationWelcomeLabel = new JLabel("Welcome Admins! choose resume templates to delete, edit, create resume templates",SwingConstants.CENTER); //this creates and names the label ,placing it at the center
        AiResumeBuilderAdminModificationWelcomeLabel.setFont(new Font("Arial", Font.BOLD, 24)); //this sets the font name,font type and size label for the welcome label
        AiResumeBuilderAdminResumeModificationPanel.add(AiResumeBuilderAdminModificationWelcomeLabel); //this adds the welcome label to the panel
        AiResumeBuilderAdminResumeModificationPanel.add(Box.createRigidArea(new Dimension(0, 30))); //this adds space around the admin resume modification panel

        JButton AiResumeBuilderAdminTemplate1 = new JButton("Resume category options: Technology and engineering"); //this creates and names the button
        AiResumeBuilderAdminResumeModificationPanel.add(AiResumeBuilderAdminTemplate1); //this adds the button to the panel
        AiResumeBuilderAdminResumeModificationPanel.add(Box.createRigidArea(new Dimension(0, 30))); //this adds space around the admin resume modification panel

        JButton AiResumeBuilderAdminTemplate2 = new JButton("Resume category options: Creative Arts"); //this creates and names the button
        AiResumeBuilderAdminResumeModificationPanel.add(AiResumeBuilderAdminTemplate2); //this adds the button to the panel
        AiResumeBuilderAdminResumeModificationPanel.add(Box.createRigidArea(new Dimension(0, 30))); //this adds space around the admin resume modification panel

        JButton AiResumeBuilderAdminTemplate3 = new JButton("Resume category options: Business and management "); //this creates and names the button
        AiResumeBuilderAdminResumeModificationPanel.add(AiResumeBuilderAdminTemplate3); //this adds the button to the panel
        AiResumeBuilderAdminResumeModificationPanel.add(Box.createRigidArea(new Dimension(0, 30))); //this adds space around the admin resume modification panel

        JButton AiResumeBuilderAdminTemplate4 = new JButton("Resume category options: Healthcare and Science"); //this creates and names the button
        AiResumeBuilderAdminResumeModificationPanel.add(AiResumeBuilderAdminTemplate4); //this adds the button to the panel
        AiResumeBuilderAdminResumeModificationPanel.add(Box.createRigidArea(new Dimension(0, 30))); //this adds space around the admin resume modification panel

        JButton AiResumeBuilderAdminTemplate5 = new JButton("Resume category options: Education and Training "); //this creates and names the button
        AiResumeBuilderAdminResumeModificationPanel.add(AiResumeBuilderAdminTemplate5); //this adds the button to the panel
        AiResumeBuilderAdminResumeModificationPanel.add(Box.createRigidArea(new Dimension(0, 30))); //this adds space around the admin resume modification panel

        JButton AiResumeBuilderAdminTemplate6 = new JButton("Resume category options: Law and government "); //this creates and names the button
        AiResumeBuilderAdminResumeModificationPanel.add(AiResumeBuilderAdminTemplate6); //this adds the button to the panel
        AiResumeBuilderAdminResumeModificationPanel.add(Box.createRigidArea(new Dimension(0, 30))); //this adds space around the admin resume modification panel

        JButton AiResumeBuilderAdminTemplate7 = new JButton("Resume category options: Finance and Accounting "); //this creates and names the button
        AiResumeBuilderAdminResumeModificationPanel.add(AiResumeBuilderAdminTemplate7); //this adds the button to the panel
        AiResumeBuilderAdminResumeModificationPanel.add(Box.createRigidArea(new Dimension(0, 30))); //this adds space around the admin resume modification panel

        JButton AiResumeBuilderAdminTemplate8 = new JButton("Resume category options: Sales and Customer service "); //this creates and names the button
        AiResumeBuilderAdminResumeModificationPanel.add(AiResumeBuilderAdminTemplate8); //this adds the button to the panel
        AiResumeBuilderAdminResumeModificationPanel.add(Box.createRigidArea(new Dimension(0, 30))); //this adds space around the admin resume modification panel

        JButton AiResumeBuilderDeletingResumes = new JButton("Deleting resumes"); //this creates and names the JButton
        AiResumeBuilderAdminResumeModificationPanel.add(AiResumeBuilderDeletingResumes); //this adds the JButton to the panel
        JButton AiResumeBuilderEditingResumes = new JButton("Editing resumes"); //this creates and names the JButton
        AiResumeBuilderAdminResumeModificationPanel.add(AiResumeBuilderEditingResumes); //this adds the JButton to the panel
        JButton AiResumeBuilderCreatingResumes = new JButton("Creating resumes"); //this creates and names the JButton
        AiResumeBuilderAdminResumeModificationPanel.add(AiResumeBuilderCreatingResumes); //this adds the JButton to the panel
        AiResumeBuilderAdminResumeModificationPanel.add(Box.createRigidArea(new Dimension(0, 30))); //this adds space around the admin resume modification panel

        AiResumeBuilderAdminResumeModificationPanel.add(new JLabel("User feedbacks:",SwingConstants.CENTER)); //this creates the JLabel called "Username", placing it at the center
        AiResumeBuilderAdminResumeModificationPanel.add(Box.createRigidArea(new Dimension(0, 30))); //this adds space around the admin resume modification panel
        AiResumeBuilderAdminResumeModificationPanel.add(new JLabel("user 2- I hope for future enhancements , We can export the resume to a PDF format",SwingConstants.CENTER)); //this creates and names the JLabel called , placing it at the center
        AiResumeBuilderAdminResumeModificationFrame.add(AiResumeBuilderAdminResumeModificationPanel); //this adds the panel to the frame
        AiResumeBuilderAdminResumeModificationFrame.setVisible(true); //this makes sure that the frame is visible
    }


// User Sign Up Page
    private static void AiResumeBuilderOpenUserSignUpPage() { //this method opens user sign up page
        JFrame AiResumeBuilderUserSignUpFrame = new JFrame("User Sign Up"); //this creates and names the frame to "User Sign up"
        AiResumeBuilderUserSignUpFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); //this makes sure that the user sign up frame will be closed but the main application will still be running in the background
        AiResumeBuilderUserSignUpFrame.setSize(5000, 1000); //this sets the size of the frame/window screen for the user signup page
        JPanel AiResumeBuilderUserSignUpPanel = new JPanel(); //this creates the JPanel for the user sign up page
        AiResumeBuilderUserSignUpPanel.setLayout(new GridLayout(20, 10, 10, 10)); //this sets the grid layouts for the user sign up panel

        AiResumeBuilderUserSignUpPanel.add(new JLabel("First name",SwingConstants.CENTER)); //this creates the JLabel called "First name", placing it at the center
        JTextField AiResumeBuilderUserSignUpFirstNameField = new JTextField(10); //this creates the first name text field for the user sign up
        AiResumeBuilderUserSignUpPanel.add(AiResumeBuilderUserSignUpFirstNameField); //this adds the first name textfield to the user signup panel

        AiResumeBuilderUserSignUpPanel.add(new JLabel("Last name",SwingConstants.CENTER)); //this creates the JLabel called "Last name", placing it at the center
        JTextField AiResumeBuilderUserSignUpLastNameField = new JTextField(10); //this creates the last name text field for the user sign up
        AiResumeBuilderUserSignUpPanel.add(AiResumeBuilderUserSignUpLastNameField); //this adds the last name textfield to the user signup panel

        AiResumeBuilderUserSignUpPanel.add(new JLabel("Email Address",SwingConstants.CENTER)); //this creates the JLabel called "Email Address", placing it at the center
        JTextField AiResumeBuilderUserSignUpEmailAddressField = new JTextField(10); //this creates the email address text field for the user sign up
        AiResumeBuilderUserSignUpPanel.add(AiResumeBuilderUserSignUpEmailAddressField); //this adds the email address textfield to the user signup panel

        AiResumeBuilderUserSignUpPanel.add(new JLabel("Phone Number (optional)",SwingConstants.CENTER)); //this creates the JLabel called "Phone Number (optional)", placing it at the center
        JTextField AiResumeBuilderUserSignUpPhoneNumberField = new JTextField(10); //this creates the phone number text field for the user sign up
        AiResumeBuilderUserSignUpPanel.add(AiResumeBuilderUserSignUpPhoneNumberField); //this adds the phone number textfield to the user signup panel

        AiResumeBuilderUserSignUpPanel.add(new JLabel("Username:",SwingConstants.CENTER)); //this creates the JLabel called "Username", placing it at the center
        JTextField AiResumeBuilderUserSignUpUsernameField = new JTextField(10); //this creates the username text field for the user sign up
        AiResumeBuilderUserSignUpPanel.add(AiResumeBuilderUserSignUpUsernameField); //this adds the username textfield to the user signup panel

        AiResumeBuilderUserSignUpPanel.add(new JLabel("Password:",SwingConstants.CENTER)); //this creates the JLabel called "Password", placing it at the center
        JPasswordField AiResumeBuilderUserSignUpPasswordField = new JPasswordField(10); //this creates the password text field for the user sign up
        AiResumeBuilderUserSignUpPanel.add(AiResumeBuilderUserSignUpPasswordField); //this adds the password textfield to the user signup panel

        AiResumeBuilderUserSignUpPanel.add(new JLabel("Confirm Password:",SwingConstants.CENTER)); //this creates the JLabel called "Confirm Password", placing it at the center
        JPasswordField AiResumeBuilderUserSignUpConfirmPasswordField = new JPasswordField(10); //this creates the Confirm password text field for the user sign up
        AiResumeBuilderUserSignUpPanel.add(AiResumeBuilderUserSignUpConfirmPasswordField); //this adds the Confirm password textfield to the user signup panel

        AiResumeBuilderUserSignUpPanel.add(Box.createRigidArea(new Dimension(0, 10))); //this adds space around the user sign up panel

        JButton AiResumeBuilderUserSignUpSubmitButton = new JButton("Submit"); //this adds the JButton called submit to the user sign up page
        AiResumeBuilderUserSignUpPanel.add(AiResumeBuilderUserSignUpSubmitButton); //this adds the user sign up button to the user sign up panel
        AiResumeBuilderUserSignUpFrame.add(AiResumeBuilderUserSignUpPanel); //this adds the user sign up panel to the user sign up frame
        AiResumeBuilderUserSignUpFrame.setVisible(true); //this makes sure that the user sign up frame is actually visible
        AiResumeBuilderUserSignUpSubmitButton.addActionListener(e -> { //this detects when users clicked the submit button for signing up
            JOptionPane.showMessageDialog(null, "Account has been successfully created", "welcome to the Ai Resume Builder", JOptionPane.INFORMATION_MESSAGE); //this displays the message dialog
        });
    }
    // User Log In Page
    private static void AiResumeBuilderOpenUserLoginPage() { //this method opens the user login page
        JFrame AiResumeBuilderUserLoginFrame = new JFrame("User Log In"); //this creates and names the frame to "User Login"
        AiResumeBuilderUserLoginFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); //this makes sure that the user login frame will be closed but the main application will still be running in the background
        AiResumeBuilderUserLoginFrame.setSize(5000, 1000); //this sets the size of the frame/window screen for the user login page
        JPanel AiResumeBuilderUserLoginPanel = new JPanel(); //this creates the JPanel for the user login page
        AiResumeBuilderUserLoginPanel.setLayout(new GridLayout(20, 10, 10, 10)); //this sets the grid layouts for the user login panel

        AiResumeBuilderUserLoginPanel.add(Box.createRigidArea(new Dimension(0, 10))); //this adds space around the user login panel

        AiResumeBuilderUserLoginPanel.add(new JLabel("Username:",SwingConstants.CENTER)); //this creates the JLabel called "Username", placing it at the center
        JTextField AiResumeBuilderUserLoginUsernameField = new JTextField(10); //this creates the username text field for the user login
        AiResumeBuilderUserLoginPanel.add(AiResumeBuilderUserLoginUsernameField); //this adds the username textfield to the user login panel

        AiResumeBuilderUserLoginPanel.add(Box.createRigidArea(new Dimension(0, 10))); //this adds space around the user login panel

        AiResumeBuilderUserLoginPanel.add(new JLabel("Password:",SwingConstants.CENTER)); //this creates the JLabel called "Password", placing it at the center
        JPasswordField AiResumeBuilderUserLoginPasswordField = new JPasswordField(10); //this creates the password text field for the user login
        AiResumeBuilderUserLoginPanel.add(AiResumeBuilderUserLoginPasswordField); //this adds the password textfield to the user login panel

        AiResumeBuilderUserLoginPanel.add(Box.createRigidArea(new Dimension(0, 10))); //this adds space around the user login panel

        JButton AiResumeBuilderUserLoginButton = new JButton("Submit"); //this adds the JButton called submit to the user login page
        AiResumeBuilderUserLoginPanel.add(AiResumeBuilderUserLoginButton); //this adds the user login button to the user login panel
        AiResumeBuilderUserLoginButton.addActionListener(e -> { //this detects when users clicked the login button
            AiResumeBuilderUserLoginFrame.dispose(); //this close the user login frame, while home page is still running in the background
            AiResumeBuilderOpenUserResumeSelectionPage(); //this opens the user resume selection window
        });
        AiResumeBuilderUserLoginPanel.add(AiResumeBuilderUserLoginButton);//this adds the button to the panel
        AiResumeBuilderUserLoginFrame.add(AiResumeBuilderUserLoginPanel);//this adds the panel to the frame
        AiResumeBuilderUserLoginFrame.setVisible(true); //this makes sure the frame is visible
    }

    private static void AiResumeBuilderOpenUserResumeSelectionPage(){ // this method opens the user resume selection page
        JFrame AiResumeBuilderUserResumeSelectionFrame = new JFrame("User Resume Selection");//this creates and names the frame as "Resume Selection"
        AiResumeBuilderUserResumeSelectionFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);//thi closes the user resume selection, while homepage still runs in the background
        AiResumeBuilderUserResumeSelectionFrame.setSize(5000, 1000);//this sets the frame size to fit the whole screen
       JPanel AiResumeBuilderUserResumeSelectionPanel = new JPanel();//this creates and names the JPanel
       AiResumeBuilderUserResumeSelectionPanel.setLayout(new BoxLayout(AiResumeBuilderUserResumeSelectionPanel, BoxLayout.Y_AXIS));//this sets the layout for the panel to vertical Y axis BoxLayout
       AiResumeBuilderUserResumeSelectionPanel.add(Box.createRigidArea(new Dimension(0, 30)));//this adds space around the panel

       JLabel AiResumeBuilderUserSelectionWelcomeLabel = new JLabel("Welcome Users! Please pick a resume template of your choice",SwingConstants.CENTER);//this creates and names the welcome label, placing it at the center
       AiResumeBuilderUserSelectionWelcomeLabel.setFont(new Font("Arial", Font.BOLD, 24));//this sets the font name, font type, and size for the welcome label
       AiResumeBuilderUserResumeSelectionPanel.add(AiResumeBuilderUserSelectionWelcomeLabel);//this adds the welcome label to the panel
       AiResumeBuilderUserResumeSelectionPanel.add(Box.createRigidArea(new Dimension(0, 30)));//this adds space around the panel

      JButton AiResumeBuilderUserTemplate1 = new JButton("Resume category options: Technology and engineering"); //this creates and names the button
      AiResumeBuilderUserResumeSelectionPanel.add(AiResumeBuilderUserTemplate1);//this adds the button to the panel
      AiResumeBuilderUserResumeSelectionPanel.add(Box.createRigidArea(new Dimension(0, 30)));//this adds space around the panel

      JButton AiResumeBuilderUserTemplate2 = new JButton("Resume category options: Creative Arts");//this creates and names the button
      AiResumeBuilderUserResumeSelectionPanel.add(AiResumeBuilderUserTemplate2);//this adds the button to the panel
      AiResumeBuilderUserResumeSelectionPanel.add(Box.createRigidArea(new Dimension(0, 30)));//this adds space around the panel

      JButton AiResumeBuilderUserTemplate3 = new JButton("Resume category options: Business and management ");//this creates and names the button
      AiResumeBuilderUserResumeSelectionPanel.add(AiResumeBuilderUserTemplate3);//this adds the button to the panel
      AiResumeBuilderUserResumeSelectionPanel.add(Box.createRigidArea(new Dimension(0, 30)));//this adds space around the panel

      JButton AiResumeBuilderUserTemplate4 = new JButton("Resume category options: Healthcare and Science");//this creates and names the button
      AiResumeBuilderUserResumeSelectionPanel.add(AiResumeBuilderUserTemplate4);//this adds the button to the panel
      AiResumeBuilderUserResumeSelectionPanel.add(Box.createRigidArea(new Dimension(0, 30)));//this adds space around the panel

      JButton AiResumeBuilderUserTemplate5 = new JButton("Resume category options: Education and Training ");//this creates and names the button
      AiResumeBuilderUserResumeSelectionPanel.add(AiResumeBuilderUserTemplate5);//this adds the button to the panel
      AiResumeBuilderUserResumeSelectionPanel.add(Box.createRigidArea(new Dimension(0, 30)));//this adds space around the panel

      JButton AiResumeBuilderUserTemplate6 = new JButton("Resume category options: Law and government ");//this creates and names the button
      AiResumeBuilderUserResumeSelectionPanel.add(AiResumeBuilderUserTemplate6);//this adds the button to the panel
      AiResumeBuilderUserResumeSelectionPanel.add(Box.createRigidArea(new Dimension(0, 30)));//this adds space around the panel

      JButton AiResumeBuilderUserTemplate7 = new JButton("Resume category options: Finance and Accounting ");//this creates and names the button
      AiResumeBuilderUserResumeSelectionPanel.add(AiResumeBuilderUserTemplate7);//this adds the button to the panel
      AiResumeBuilderUserResumeSelectionPanel.add(Box.createRigidArea(new Dimension(0, 30)));//this adds space around the panel

      JButton AiResumeBuilderUserTemplate8 = new JButton("Resume category options: Sales and Customer service ");//this creates and names the button
      AiResumeBuilderUserResumeSelectionPanel.add(AiResumeBuilderUserTemplate8);//this adds the button to the panel
      AiResumeBuilderUserResumeSelectionPanel.add(Box.createRigidArea(new Dimension(0, 30)));//this adds space around the panel

      AiResumeBuilderUserResumeSelectionPanel.add(new JLabel("Enter feedback:",SwingConstants.CENTER)); //this creates the JLabel called "Enter Feedback", placing it at the center
      JTextField AiResumeBuilderUserFeedbackField = new JTextField(10); //this creates the text field for feedback entry
      AiResumeBuilderUserResumeSelectionPanel.add(AiResumeBuilderUserFeedbackField); //this adds the text field to the panel
      AiResumeBuilderUserResumeSelectionFrame.add(AiResumeBuilderUserResumeSelectionPanel);//this adds the panel in the frame
      AiResumeBuilderUserResumeSelectionFrame.setVisible(true);// this makes sure that the frame is visible

        AiResumeBuilderUserTemplate1.addActionListener(new ActionListener() { //this detects when users clicked the template button
            @Override
            public void actionPerformed(ActionEvent e) { //code runs when the action listner detects that the user has clicked the template button
                AiResumeBuilderTechnologyEngineeringPage(); //this opens the Technology and Engineering window
                AiResumeBuilderUserResumeSelectionFrame.dispose(); //this closes the frame without closing the main home page that still runs in the background
            }
        });
    }
    private static void AiResumeBuilderTechnologyEngineeringPage() { //this method opens the Technology Engineering page window
        JFrame AiResumeBuilderTemplate1Frame = new JFrame("Technology and Engineering Resume Details"); //this creates and names the frame as "Technology and Engineering Resume Details"
        AiResumeBuilderTemplate1Frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); //this closes the template frame without closing the main home page that still runs in the background
        AiResumeBuilderTemplate1Frame.setSize(5000, 1000); //this sets the size of the frame/window screen for the template frame
        JPanel AiResumeBuilderTemplate1Panel = new JPanel(); //this creates and names the JPanel as AiResumeBuilderTemplate1Panel
        AiResumeBuilderTemplate1Frame.setVisible(true); // Make the technology frame visible
        AiResumeBuilderTemplate1Panel.setLayout(new GridLayout(20, 10, 10, 10)); //this sets the grid layouts for the template panel

        AiResumeBuilderTemplate1Panel.add(new JLabel("Full name",SwingConstants.CENTER)); //this creates and names the JLabel, placing it at the center
        JTextField AiResumeBuilderTemplate1FullNameField = new JTextField(10); //this creates the text field for the template panel
        AiResumeBuilderTemplate1Panel.add(AiResumeBuilderTemplate1FullNameField); //this adds the textfield to the template panel

        AiResumeBuilderTemplate1Panel.add(new JLabel("Email",SwingConstants.CENTER)); //this creates and names the JLabel, placing it at the center
        JTextField AiResumeBuilderTemplate1EmailField = new JTextField(10); //this creates the text field for the template panel
        AiResumeBuilderTemplate1Panel.add(AiResumeBuilderTemplate1EmailField); //this adds the textfield to the template panel

        AiResumeBuilderTemplate1Panel.add(new JLabel("phone number",SwingConstants.CENTER)); //this creates and names the JLabel, placing it at the center
        JTextField AiResumeBuilderTemplate1PhoneNumberField = new JTextField(10); //this creates the text field for the template panel
        AiResumeBuilderTemplate1Panel.add(AiResumeBuilderTemplate1PhoneNumberField); //this adds the textfield to the template panel

        AiResumeBuilderTemplate1Panel.add(new JLabel("highest education",SwingConstants.CENTER));//this creates and names the JLabel, placing it at the center
        JTextField AiResumeBuilderTemplate1HighestEducation = new JTextField(10);//this creates the text field for the template panel
        AiResumeBuilderTemplate1Panel.add(AiResumeBuilderTemplate1HighestEducation);//this adds the textfield to the template panel

        AiResumeBuilderTemplate1Panel.add(new JLabel("work experience",SwingConstants.CENTER));//this creates and names the JLabel, placing it at the center
        JTextField AiResumeBuilderTemplate1WorkExperience = new JTextField(10);//this creates the text field for the template panel
        AiResumeBuilderTemplate1Panel.add(AiResumeBuilderTemplate1WorkExperience);//this adds the textfield to the template panel

        AiResumeBuilderTemplate1Panel.add(new JLabel("projects",SwingConstants.CENTER));//this creates and names the JLabel, placing it at the center
        JTextField AiResumeBuilderTemplate1ProjectsField = new JTextField(10);//this creates the text field for the template panel
        AiResumeBuilderTemplate1Panel.add(AiResumeBuilderTemplate1ProjectsField);//this adds the textfield to the template panel

        AiResumeBuilderTemplate1Panel.add(new JLabel("key skills",SwingConstants.CENTER));//this creates and names the JLabel, placing it at the center
        JTextField AiResumeBuilderTemplate1KeySkills = new JTextField(10);//this creates the text field for the template panel
        AiResumeBuilderTemplate1Panel.add(AiResumeBuilderTemplate1KeySkills);//this adds the textfield to the template panel

        JButton AiResumeBuilderTemplateGenerateButton = new JButton("Generate Resume");//this creates and names the JButton to "Generate Resume"
        AiResumeBuilderTemplate1Panel.add(new JLabel()); //this adds the label to the panel
        AiResumeBuilderTemplate1Panel.add(AiResumeBuilderTemplateGenerateButton);//this adds the template generating button to the template panel

        AiResumeBuilderTemplateGenerateButton.addActionListener(e -> {//this triggers when the user clicks the button to output resume
            String resumeContent = "----- Resume -----\n" //this is the resume content that will output as a txt format
                    + "Name: " +  AiResumeBuilderTemplate1FullNameField.getText() + "\n"//this is the resume content that will output as a txt format
                    + "Email: " + AiResumeBuilderTemplate1EmailField.getText() + "\n"//this is the resume content that will output as a txt format
                    + "Phone: " + AiResumeBuilderTemplate1PhoneNumberField.getText() + "\n"//this is the resume content that will output as a txt format
                    + "Education: " + AiResumeBuilderTemplate1HighestEducation.getText() + "\n"//this is the resume content that will output as a txt format
                    + "Skills: " + AiResumeBuilderTemplate1WorkExperience.getText() + "\n"//this is the resume content that will output as a txt format
                    + "Project: " + AiResumeBuilderTemplate1ProjectsField.getText() + "\n"//this is the resume content that will output as a txt format
                    + "Experience: " + AiResumeBuilderTemplate1KeySkills.getText() + "\n";//this is the resume content that will output as a txt format

            try (BufferedWriter writer = new BufferedWriter(new FileWriter(AiResumeBuilderTemplate1FullNameField.getText() + "_Resume.txt"))) {
                writer.write(resumeContent);//this names the txt file with title and full name of the user
                JOptionPane.showMessageDialog(AiResumeBuilderTemplate1Panel, "Resume has been saved successfully as '" + AiResumeBuilderTemplate1FullNameField.getText() + "_Resume.txt'");//this shows the message
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(AiResumeBuilderTemplate1Panel, "There is an Error saving resume: " + ex.getMessage());//this shows the message when there is an error whn creating the resume
            }
        });
        AiResumeBuilderTemplate1Frame.add(AiResumeBuilderTemplate1Panel);//this adds the panel in the frame
        AiResumeBuilderTemplate1Frame.setVisible(true);//this makes sure that the frame is actually visible
    }
    }

